a = int(input())
b = int(input())
c = int(input())
n = (c - a) // b
print(n)

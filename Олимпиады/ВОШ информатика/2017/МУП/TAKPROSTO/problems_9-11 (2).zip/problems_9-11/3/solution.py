n = int(input())
m = int(input())
print(n * (n + 1) // 2 * m * (m + 1) // 2)



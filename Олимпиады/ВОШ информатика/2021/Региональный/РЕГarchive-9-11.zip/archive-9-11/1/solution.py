n = int(input())
k = int(input())
print(n * 2 * (n // k - 1))

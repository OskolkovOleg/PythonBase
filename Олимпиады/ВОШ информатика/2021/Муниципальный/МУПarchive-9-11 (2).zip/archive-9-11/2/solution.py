a = int(input())
b = int(input())
print(max(1, 2 * (a - b) + 2))

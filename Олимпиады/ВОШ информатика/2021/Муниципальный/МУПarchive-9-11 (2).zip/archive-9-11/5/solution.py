n = input()
k = int(input())
 
indexes = [[] for _ in range(10)]
for i in range(len(n)):
    indexes[int(n[i])].append(i)
for digit in range(10):
    indexes[digit].append(len(n))
    indexes[digit].reverse()
good = 0
pos = 0
ans = []
while pos < k + good < len(n):
    digit = 9
    while indexes[digit][-1] > k + good:
        digit -= 1
    for i in range(pos, indexes[digit][-1] + 1):
        indexes[int(n[i])].pop()
    pos = i + 1
    good += 1
    ans.append(str(digit))
if pos == k + good:
    ans.extend(n[pos:])
 
print("".join(ans))

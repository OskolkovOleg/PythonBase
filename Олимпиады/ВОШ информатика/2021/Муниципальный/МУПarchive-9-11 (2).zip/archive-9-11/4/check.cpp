#include <bits/stdc++.h>
#include "testlib.h"
using namespace std;
 
enum CheckerResult {
    AC,
    WA,
    PE
};
 
int n;
vector<int> a, I(3), J(3);
 
int main (int argc, char **argv) {
    setName("checker");
    registerTestlibCmd(argc, argv);
 
    n = inf.readInt();
    a.resize(n);
    for (int i = 0; i < n; ++i) 
        a[i] = inf.readInt();
 
    I[0] = ans.readInt();
    if (I[0] != 0)
        for (int i = 1; i < 3; ++i)
            I[i] = ans.readInt();
    
    J[0] = ouf.readInt();
    if (J[0] != 0)
        for (int i = 1; i < 3; ++i)
            J[i] = ouf.readInt();
    
    if (J[0] == 0) {
        if (I[0] == 0)
            quitf(_ok, "OK\n");
        else
            quitf(_wa, "No solution found, but it exists\n");
    }
    if (J[0] < 1 || J[0] > n || J[1] < 1 || J[1] > n || J[2] < 1 || J[2] > n) 
        quitf(_wa, "Not correct indexes\n");
    if (!(J[0] < J[1] && J[1] < J[2]))
        quitf(_wa, "Not correct indexes\n");
    if (!(a[J[0]-1] < a[J[1]-1] && a[J[1]-1] < a[J[2]-1]))
        quitf(_wa, "The sequence of years does not increase\n");
    quitf(_ok, "OK\n");
}

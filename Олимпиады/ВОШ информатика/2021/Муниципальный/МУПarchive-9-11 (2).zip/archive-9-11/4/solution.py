n = int(input())
i = 0
i_val = 10 ** 9
ans_i = 0
ans_j = 0
j_val = 10 ** 9
for k in range(1, n + 1):
    year = int(input())
    if year > j_val:
        print(ans_i, ans_j, k)
        break
    if i_val < year < j_val:
        j_val = year
        ans_i = i
        ans_j = k
    if year < i_val:
        i_val = year
        i = k
else:
    print(0)

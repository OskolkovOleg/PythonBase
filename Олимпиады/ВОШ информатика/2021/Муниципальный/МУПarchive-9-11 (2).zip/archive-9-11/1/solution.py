n = int(input())
a = int(input())
b = int(input())
s = a + 3 * b
ans = s // n
if n % 3 != 0:
    ans = min(ans, a // (n % 3))
print(ans)

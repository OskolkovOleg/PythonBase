import sys

count = [int(input()) for i in range(4)]
DX = [0, 1, 0, -1]
DY = [1, 0, -1, 0]
k = int(input())
x = 0
y = 0
steps = 0
for i in range(4):
    x += DX[i] * count[i]
    y += DY[i] * count[i]
    steps += count[i]
    if abs(x) >= k:
        print(steps - abs(x) + k)
        sys.exit(0)
    if abs(y) >= k:
        print(steps - abs(y) + k)
        sys.exit(0)
ans = 10 ** 19
if y > 0:
    p = (k - count[0] + y - 1) // y
    ans = min(ans, steps * p + k - p * y)
if x > 0:
    p = (k - count[1] + x - 1) // x
    ans = min(ans, steps * p + k - p * x + count[0])
if y < 0:
    p = (k - count[2] + count[0] - y - 1) // -y
    ans = min(ans, steps * p + k + p * y + count[0] * 2 + count[1])
if x < 0:
    p = (k - count[3] + count[1] - x - 1) // -x
    ans = min(ans, steps * p + k + p * x + count[0] + count[1] * 2 + count[2])
print(ans)


h = int(input())
a = int(input())
b = int(input())
ans = h - a + b
print(ans)


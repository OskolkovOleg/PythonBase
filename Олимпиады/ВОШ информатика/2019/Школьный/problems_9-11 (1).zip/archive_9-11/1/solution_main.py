h = int(input())
a = int(input())
b = int(input())

ans = (h - a + b) % 24
print(ans)

